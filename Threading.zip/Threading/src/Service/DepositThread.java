package Service;

import Entity.Account;

public class DepositThread extends AccountService implements Runnable{
    //private Account acc;
    //private double amount;
    public DepositThread(Account acc, double amount){
        super(acc, amount);
    }
    @Override
    public void run() {
        super.deposit();
    }
}
