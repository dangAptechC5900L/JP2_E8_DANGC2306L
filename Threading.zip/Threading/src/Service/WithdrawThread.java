package Service;

import Entity.Account;

public class WithdrawThread implements Runnable{
    private Account acc;
    private double amount;
    public WithdrawThread(Account acc, double amount){
        this.acc = acc;
        this.amount = amount;
    }
    @Override
    public void run() {
        AccountService as = new AccountService(acc, amount);
        as.withdraw();
    }
}
